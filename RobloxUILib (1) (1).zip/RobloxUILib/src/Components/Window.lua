--!strict

local Roact = require(script.Parent.Parent.init).Roact
local BaseComponent = require(script.Parent.BaseComponent)
local StyleManager = require(script.Parent.Parent.Styles.StyleManager)

local Window = Roact.Component:extend("Window")

function Window:init()
    BaseComponent.init(self)
    self:setState({
        isDragging = false,
        startPosition = Vector2.new(0, 0),
        startMousePosition = Vector2.new(0, 0),
        isLocked = self.props.IsLocked or false, -- New state for locking
        isResizing = false,
        resizeStartMousePosition = Vector2.new(0, 0),
        resizeStartSize = UDim2.new(0, 0, 0, 0),
    })
end

function Window:render()
    local props = self.props
    local state = self.state

    local size = props.Size or UDim2.new(0, 500, 0, 400)
    local position = props.Position or UDim2.new(0.5, 0, 0.5, 0)
    local anchorPoint = props.AnchorPoint or Vector2.new(0.5, 0.5)
    local backgroundColor = props.BackgroundColor or StyleManager:GetColor("Secondary")
    local title = props.Title or "UI Window"

    return Roact.createElement("Frame", {
        Size = size,
        Position = position,
        AnchorPoint = anchorPoint,
        BackgroundColor3 = backgroundColor,
        BorderSizePixel = 0,
        -- Draggable functionality
        [Roact.Event.InputBegan] = function(rbx, input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 and not state.isLocked then
                local mousePos = input.Position
                local rbxPos = rbx.AbsolutePosition
                local rbxSize = rbx.AbsoluteSize

                -- Check if resizing from bottom-right corner
                if mousePos.X > rbxPos.X + rbxSize.X - 10 and mousePos.Y > rbxPos.Y + rbxSize.Y - 10 then
                    self:setState({
                        isResizing = true,
                        resizeStartMousePosition = mousePos,
                        resizeStartSize = rbx.Size,
                    })
                else
                    self:setState({
                        isDragging = true,
                        startPosition = rbx.AbsolutePosition,
                        startMousePosition = mousePos,
                    })
                end
            end
        end,
        [Roact.Event.InputEnded] = function(rbx, input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 then
                self:setState({ isDragging = false, isResizing = false })
            end
        end,
        [Roact.Event.InputChanged] = function(rbx, input)
            if input.UserInputType == Enum.UserInputType.MouseMovement then
                if state.isDragging and not state.isLocked then
                    local delta = input.Position - state.startMousePosition
                    local newX = state.startPosition.X + delta.X
                    local newY = state.startPosition.Y + delta.Y
                    rbx.Position = UDim2.new(0, newX, 0, newY)
                elseif state.isResizing then
                    local delta = input.Position - state.resizeStartMousePosition
                    local newWidth = math.max(100, state.resizeStartSize.X.Offset + delta.X)
                    local newHeight = math.max(100, state.resizeStartSize.Y.Offset + delta.Y)
                    rbx.Size = UDim2.new(0, newWidth, 0, newHeight)
                end
            end
        end,
    }, {
        -- Title Bar
        TitleBar = Roact.createElement("Frame", {
            Size = UDim2.new(1, 0, 0, 30),
            Position = UDim2.new(0, 0, 0, 0),
            BackgroundColor3 = StyleManager:GetColor("Background"), -- Slightly darker title bar
            BorderSizePixel = 0,
        }, {
            TitleLabel = Roact.createElement("TextLabel", {
                Size = UDim2.new(1, -60, 1, 0), -- Make space for close/minimize buttons if added later
                Position = UDim2.new(0, 10, 0, 0),
                BackgroundColor3 = StyleManager:GetColor("Background"),
                BackgroundTransparency = 1,
                Text = title,
                TextColor3 = StyleManager:GetColor("Text"),
                TextScaled = true,
                Font = Enum.Font.SourceSansBold,
                TextXAlignment = Enum.TextXAlignment.Left,
            }),
        }),
        -- Content Area
        Content = Roact.createElement("Frame", {
            Size = UDim2.new(1, 0, 1, -30),
            Position = UDim2.new(0, 0, 0, 30),
            BackgroundColor3 = backgroundColor,
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
        }, props[Roact.Children]), -- Render children inside the content area

        -- Resize Handle (bottom-right corner)
        ResizeHandle = Roact.createElement("Frame", {
            Size = UDim2.new(0, 10, 0, 10),
            Position = UDim2.new(1, -10, 1, -10),
            AnchorPoint = Vector2.new(1, 1),
            BackgroundColor3 = StyleManager:GetColor("Border"),
            BorderSizePixel = 0,
            ZIndex = 2, -- Ensure it's on top for interaction
        }),
    })
end

return Window


