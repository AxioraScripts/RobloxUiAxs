--!strict

local Roact = require(script.Parent.Parent.init).Roact
local BaseComponent = require(script.Parent.BaseComponent)

local ImageParagraph = Roact.Component:extend("ImageParagraph")

function ImageParagraph:render()
    local props = self.props

    local imageUrl = props.ImageUrl or ""
    local text = props.Text or ""
    local textColor = props.TextColor or Color3.new(1, 1, 1)
    local textSize = props.TextSize or 14
    local font = props.Font or Enum.Font.SourceSans
    local imageSize = props.ImageSize or UDim2.new(0, 50, 0, 50)
    local layoutDirection = props.LayoutDirection or "Horizontal" -- "Horizontal" or "Vertical"

    local children = {}

    if layoutDirection == "Horizontal" then
        table.insert(children, Roact.createElement("ImageLabel", {
            Size = imageSize,
            Image = imageUrl,
            BackgroundTransparency = 1,
            ScaleType = Enum.ScaleType.Fit,
        }))
        table.insert(children, Roact.createElement("TextLabel", {
            Size = UDim2.new(1, -imageSize.X.Offset, 1, 0), -- Fill remaining width
            Position = UDim2.new(0, imageSize.X.Offset, 0, 0),
            BackgroundTransparency = 1,
            Text = text,
            TextColor3 = textColor,
            TextSize = textSize,
            Font = font,
            TextWrapped = true,
            TextXAlignment = Enum.TextXAlignment.Left,
            TextYAlignment = Enum.TextYAlignment.Top,
        }))
    else -- Vertical
        table.insert(children, Roact.createElement("ImageLabel", {
            Size = imageSize,
            Image = imageUrl,
            BackgroundTransparency = 1,
            ScaleType = Enum.ScaleType.Fit,
        }))
        table.insert(children, Roact.createElement("TextLabel", {
            Size = UDim2.new(1, 0, 1, -imageSize.Y.Offset), -- Fill remaining height
            Position = UDim2.new(0, 0, 0, imageSize.Y.Offset),
            BackgroundTransparency = 1,
            Text = text,
            TextColor3 = textColor,
            TextSize = textSize,
            Font = font,
            TextWrapped = true,
            TextXAlignment = Enum.TextXAlignment.Left,
            TextYAlignment = Enum.TextYAlignment.Top,
        }))
    end

    return Roact.createElement("Frame", {
        Size = props.Size or UDim2.new(1, 0, 0, 100), -- Default size
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
    }, children)
end

return ImageParagraph


