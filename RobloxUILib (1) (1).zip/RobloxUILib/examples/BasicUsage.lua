--!strict

-- This script demonstrates how to use the AXS UI Library.
-- It assumes AXS.lua is loaded via loadstring or is available in ReplicatedStorage.

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

-- In a real scenario, AXS would be loaded via loadstring:
-- local AXS = loadstring(game:HttpGet("YOUR_GITHUB_RAW_URL_HERE"))()

-- For local testing, you might require it directly if placed in ReplicatedStorage:
local AXS = require(ReplicatedStorage.AXS) -- Assuming AXS.lua is a ModuleScript in ReplicatedStorage

-- Mount the main AXS UI component to the PlayerGui
Roact.mount(Roact.createElement(AXS), LocalPlayer.PlayerGui, "AXS_UI")

print("AXS UI Library loaded and mounted.")

-- Example of changing theme (can be called from anywhere after UI is mounted)
-- AXS.StyleManager:SetTheme("Light")


