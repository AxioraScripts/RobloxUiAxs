--!strict

local Roact = require(script.Parent.Parent.init).Roact
local BaseComponent = require(script.Parent.BaseComponent)

local ColorPicker = Roact.Component:extend("ColorPicker")

function ColorPicker:init()
    BaseComponent.init(self)
    self:setState({
        SelectedColor = self.props.DefaultValue or Color3.new(1, 0, 0), -- Default to red
        IsPicking = false,
        Hue = 0, -- 0-360
        Saturation = 1, -- 0-1
        Value = 1, -- 0-1 (Brightness)
    })
    self:updateHSVFromColor(self.state.SelectedColor)
end

function ColorPicker:updateHSVFromColor(color)
    local h, s, v = color:ToHSV()
    self:setState({
        Hue = h * 360,
        Saturation = s,
        Value = v,
    })
end

function ColorPicker:render()
    local props = self.props
    local state = self.state

    local width = props.Width or 200
    local height = props.Height or 200
    local previewSize = props.PreviewSize or 30
    local borderColor = props.BorderColor or Color3.new(0.1, 0.1, 0.1)

    local h = state.Hue / 360
    local s = state.Saturation
    local v = state.Value

    local currentColor = Color3.fromHSV(h, s, v)

    return Roact.createElement("Frame", {
        Size = UDim2.new(0, width, 0, height + previewSize + 10), -- Add space for preview and sliders
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
    }, {
        -- Color preview
        ColorPreview = Roact.createElement("Frame", {
            Size = UDim2.new(0, previewSize, 0, previewSize),
            Position = UDim2.new(0, 0, 0, 0),
            BackgroundColor3 = currentColor,
            BorderSizePixel = 1,
            BorderColor3 = borderColor,
        }),

        -- Main color selection area (Hue, Saturation, Value)
        ColorArea = Roact.createElement("Frame", {
            Size = UDim2.new(1, 0, 0, height), -- Main picking area
            Position = UDim2.new(0, 0, 0, previewSize + 5),
            BackgroundColor3 = Color3.new(1, 1, 1), -- Will be overlaid with gradients
            BorderSizePixel = 1,
            BorderColor3 = borderColor,
            [Roact.Event.InputBegan] = function(rbx, input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 then
                    self:setState({ IsPicking = true })
                    local x = math.clamp((input.Position.X - rbx.AbsolutePosition.X) / rbx.AbsoluteSize.X, 0, 1)
                    local y = math.clamp((input.Position.Y - rbx.AbsolutePosition.Y) / rbx.AbsoluteSize.Y, 0, 1)
                    local newHue = x * 360
                    local newSaturation = 1 - y
                    local newColor = Color3.fromHSV(newHue / 360, newSaturation, state.Value)
                    self:setState({ Hue = newHue, Saturation = newSaturation, SelectedColor = newColor })
                    if props.OnChanged then
                        props.OnChanged(newColor)
                    end
                end
            end,
            [Roact.Event.InputEnded] = function(rbx, input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 then
                    self:setState({ IsPicking = false })
                end
            end,
            [Roact.Event.InputChanged] = function(rbx, input)
                if input.UserInputType == Enum.UserInputType.MouseMovement and state.IsPicking then
                    local x = math.clamp((input.Position.X - rbx.AbsolutePosition.X) / rbx.AbsoluteSize.X, 0, 1)
                    local y = math.clamp((input.Position.Y - rbx.AbsolutePosition.Y) / rbx.AbsoluteSize.Y, 0, 1)
                    local newHue = x * 360
                    local newSaturation = 1 - y
                    local newColor = Color3.fromHSV(newHue / 360, newSaturation, state.Value)
                    self:setState({ Hue = newHue, Saturation = newSaturation, SelectedColor = newColor })
                    if props.OnChanged then
                        props.OnChanged(newColor)
                    end
                end
            end,
        }, {
            -- Hue gradient (horizontal)
            HueGradient = Roact.createElement("UIGradient", {
                Color = ColorSequence.new({
                    ColorSequenceKeypoint.new(0, Color3.fromHSV(0, 1, 1)),
                    ColorSequenceKeypoint.new(1/6, Color3.fromHSV(1/6, 1, 1)),
                    ColorSequenceKeypoint.new(2/6, Color3.fromHSV(2/6, 1, 1)),
                    ColorSequenceKeypoint.new(3/6, Color3.fromHSV(3/6, 1, 1)),
                    ColorSequenceKeypoint.new(4/6, Color3.fromHSV(4/6, 1, 1)),
                    ColorSequenceKeypoint.new(5/6, Color3.fromHSV(5/6, 1, 1)),
                    ColorSequenceKeypoint.new(1, Color3.fromHSV(1, 1, 1)),
                }),
                Rotation = 0,
            }),
            -- Saturation/Value gradient (vertical)
            SaturationValueGradient = Roact.createElement("UIGradient", {
                Color = ColorSequence.new({
                    ColorSequenceKeypoint.new(0, Color3.new(1, 1, 1)),
                    ColorSequenceKeypoint.new(1, Color3.new(0, 0, 0)),
                }),
                Rotation = 90,
            }),
        }),

        -- Value (Brightness) Slider
        ValueSlider = Roact.createElement(require(script.Parent.Slider), {
            Size = UDim2.new(1, 0, 0, 20),
            Position = UDim2.new(0, 0, 0, height + previewSize + 10 - 20), -- Position below color area
            Min = 0,
            Max = 1,
            Step = 0.01,
            DefaultValue = state.Value,
            OnChanged = function(newValue)
                local newColor = Color3.fromHSV(h, s, newValue)
                self:setState({ Value = newValue, SelectedColor = newColor })
                if props.OnChanged then
                    props.OnChanged(newColor)
                end
            end,
            TrackColor = Color3.new(0.3, 0.3, 0.3),
            FillColor = currentColor,
        }),
    })
end

return ColorPicker


