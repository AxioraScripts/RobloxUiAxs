--!strict

-- Roact dependency (assuming it's available in the environment or will be loaded)
local Roact = require(game.ReplicatedStorage.Roact)

-- StyleManager Definition
local StyleManager = {}

StyleManager.Themes = {
    Default = {
        Primary = Color3.new(0.2, 0.6, 0.8), -- Blue
        Secondary = Color3.new(0.15, 0.15, 0.15), -- Dark Grey
        Accent = Color3.new(0.8, 0.4, 0.2), -- Orange
        Text = Color3.new(1, 1, 1), -- White
        Border = Color3.new(0.1, 0.1, 0.1), -- Very Dark Grey
        Background = Color3.new(0.1, 0.1, 0.1), -- Black
        InputBackground = Color3.new(0.2, 0.2, 0.2), -- Slightly lighter dark grey
        ToggleOff = Color3.new(0.3, 0.3, 0.3), -- Grey
        ToggleOn = Color3.new(0.2, 0.6, 0.8), -- Blue
        Handle = Color3.new(1, 1, 1), -- White
        OptionBackground = Color3.new(0.25, 0.25, 0.25), -- Medium dark grey
        OptionHover = Color3.new(0.3, 0.3, 0.3), -- Lighter medium dark grey
        SelectedOption = Color3.new(0.2, 0.6, 0.8), -- Blue
    },
    Light = {
        Primary = Color3.new(0.2, 0.4, 0.8),
        Secondary = Color3.new(0.9, 0.9, 0.9),
        Accent = Color3.new(0.8, 0.2, 0.4),
        Text = Color3.new(0, 0, 0),
        Border = Color3.new(0.7, 0.7, 0.7),
        Background = Color3.new(1, 1, 1),
        InputBackground = Color3.new(0.95, 0.95, 0.95),
        ToggleOff = Color3.new(0.7, 0.7, 0.7),
        ToggleOn = Color3.new(0.2, 0.4, 0.8),
        Handle = Color3.new(0, 0, 0),
        OptionBackground = Color3.new(0.85, 0.85, 0.85),
        OptionHover = Color3.new(0.8, 0.8, 0.8),
        SelectedOption = Color3.new(0.2, 0.4, 0.8),
    },
}

StyleManager.CurrentTheme = StyleManager.Themes.Default

function StyleManager:SetTheme(themeName: string)
    local theme = self.Themes[themeName]
    if theme then
        self.CurrentTheme = theme
    else
        warn("Theme \'" .. themeName .. "\' not found. Using current theme.")
    end
end

function StyleManager:GetColor(colorName: string): Color3
    local color = self.CurrentTheme[colorName]
    if color then
        return color
    else
        warn("Color \'" .. colorName .. "\' not found in current theme. Returning black.")
        return Color3.new(0, 0, 0)
    end
end

-- BaseComponent Definition
local BaseComponent = Roact.Component:extend("BaseComponent")

function BaseComponent:init()
    self.state = self.state or {}
end

function BaseComponent:render()
    error("BaseComponent:render() must be implemented by child classes")
end

-- Button Component Definition
local Button = Roact.Component:extend("Button")

function Button:init()
    BaseComponent.init(self)
    self:setState({
        isHovered = false,
        isPressed = false,
    })
end

function Button:render()
    local props = self.props
    local state = self.state

    local backgroundColor = props.BackgroundColor or StyleManager:GetColor("Primary")
    local textColor = props.TextColor or StyleManager:GetColor("Text")
    local text = props.Text or "Button"
    local size = props.Size or UDim2.new(0, 100, 0, 40)
    local position = props.Position or UDim2.new(0.5, 0, 0.5, 0)
    local anchorPoint = props.AnchorPoint or Vector2.new(0.5, 0.5)

    if state.isHovered then
        backgroundColor = backgroundColor:Lerp(StyleManager:GetColor("Primary"), 0.5) -- Lighter on hover
    end

    if state.isPressed then
        backgroundColor = backgroundColor:Lerp(StyleManager:GetColor("Primary"), 0.2) -- Darker on press
    end

    return Roact.createElement("TextButton", {
        Size = size,
        Position = position,
        AnchorPoint = anchorPoint,
        BackgroundColor3 = backgroundColor,
        Text = text,
        TextColor3 = textColor,
        TextScaled = true,
        Font = Enum.Font.SourceSans,
        [Roact.Event.MouseEnter] = function()
            self:setState({ isHovered = true })
        end,
        [Roact.Event.MouseLeave] = function()
            self:setState({ isHovered = false })
        end,
        [Roact.Event.MouseButton1Down] = function()
            self:setState({ isPressed = true })
        end,
        [Roact.Event.MouseButton1Up] = function()
            self:setState({ isPressed = false })
        end,
        [Roact.Event.Activated] = props.OnActivated,
    })
end

-- Toggle Component Definition
local Toggle = Roact.Component:extend("Toggle")

function Toggle:init()
    BaseComponent.init(self)
    self:setState({
        IsOn = self.props.DefaultValue or false,
    })
end

function Toggle:render()
    local props = self.props
    local state = self.state

    local width = props.Width or 60
    local height = props.Height or 30
    local backgroundColorOff = props.BackgroundColorOff or StyleManager:GetColor("ToggleOff")
    local backgroundColorOn = props.BackgroundColorOn or StyleManager:GetColor("ToggleOn")
    local handleColor = props.HandleColor or StyleManager:GetColor("Handle")
    local borderColor = props.BorderColor or StyleManager:GetColor("Border")
    local text = props.Text or "Toggle"

    local currentBackgroundColor = state.IsOn and backgroundColorOn or backgroundColorOff
    local handlePositionX = state.IsOn and (width - height + 5) or 5

    return Roact.createElement("Frame", {
        Size = UDim2.new(0, width, 0, height),
        BackgroundColor3 = currentBackgroundColor,
        BorderSizePixel = 1,
        BorderColor3 = borderColor,
        CornerRadius = UDim.new(0.5, 0),
        [Roact.Event.MouseButton1Click] = function()
            self:setState({ IsOn = not state.IsOn })
            if props.OnChanged then
                props.OnChanged(not state.IsOn)
            end
        end,
    }, {
        Handle = Roact.createElement("Frame", {
            Size = UDim2.new(0, height - 10, 0, height - 10),
            Position = UDim2.new(0, handlePositionX, 0.5, 0),
            AnchorPoint = Vector2.new(0, 0.5),
            BackgroundColor3 = handleColor,
            BorderSizePixel = 0,
            CornerRadius = UDim.new(0.5, 0),
        }),
        Label = Roact.createElement("TextLabel", {
            Size = UDim2.new(1, -width, 1, 0),
            Position = UDim2.new(0, width + 5, 0, 0),
            BackgroundTransparency = 1,
            Text = text,
            TextColor3 = StyleManager:GetColor("Text"),
            TextScaled = true,
            Font = Enum.Font.SourceSans,
            TextXAlignment = Enum.TextXAlignment.Left,
        }),
    })
end

-- Input Component Definition
local Input = Roact.Component:extend("Input")

function Input:init()
    BaseComponent.init(self)
    self:setState({
        Text = self.props.DefaultValue or "",
    })
end

function Input:render()
    local props = self.props
    local state = self.state

    local size = props.Size or UDim2.new(1, 0, 0, 30)
    local placeholderText = props.PlaceholderText or "Enter text..."
    local backgroundColor = props.BackgroundColor or StyleManager:GetColor("InputBackground")
    local textColor = props.TextColor or StyleManager:GetColor("Text")
    local borderColor = props.BorderColor or StyleManager:GetColor("Border")

    return Roact.createElement("TextBox", {
        Size = size,
        BackgroundColor3 = backgroundColor,
        TextColor3 = textColor,
        PlaceholderText = placeholderText,
        Text = state.Text,
        Font = Enum.Font.SourceSans,
        TextScaled = false,
        TextSize = 14,
        ClearTextOnFocus = false,
        BorderSizePixel = 1,
        BorderColor3 = borderColor,
        [Roact.Event.FocusLost] = function(rbx, enterPressed)
            if props.OnFocusLost then
                props.OnFocusLost(rbx.Text, enterPressed)
            end
        end,
        [Roact.Event.Changed] = function(rbx)
            self:setState({ Text = rbx.Text })
            if props.OnChanged then
                props.OnChanged(rbx.Text)
            end
        end,
    })
end

-- Dropdown Component Definition
local Dropdown = Roact.Component:extend("Dropdown")

function Dropdown:init()
    BaseComponent.init(self)
    self:setState({
        IsOpen = false,
        SelectedOption = self.props.DefaultValue or (self.props.Options and self.props.Options[1]) or "",
    })
end

function Dropdown:render()
    local props = self.props
    local state = self.state

    local options = props.Options or {}
    local width = props.Width or 200
    local height = props.Height or 30
    local backgroundColor = props.BackgroundColor or StyleManager:GetColor("InputBackground")
    local textColor = props.TextColor or StyleManager:GetColor("Text")
    local borderColor = props.BorderColor or StyleManager:GetColor("Border")
    local optionBackgroundColor = props.OptionBackgroundColor or StyleManager:GetColor("OptionBackground")
    local optionHoverColor = props.OptionHoverColor or StyleManager:GetColor("OptionHover")

    local dropdownElements = {}

    table.insert(dropdownElements, Roact.createElement("TextButton", {
        Size = UDim2.new(1, 0, 0, height),
        BackgroundColor3 = backgroundColor,
        TextColor3 = textColor,
        Text = state.SelectedOption,
        Font = Enum.Font.SourceSans,
        TextScaled = true,
        TextXAlignment = Enum.TextXAlignment.Left,
        TextPadding = UDim2.new(0, 10, 0, 0),
        BorderSizePixel = 1,
        BorderColor3 = borderColor,
        [Roact.Event.MouseButton1Click] = function()
            self:setState({ IsOpen = not state.IsOpen })
        end,
    }))

    if state.IsOpen then
        local yOffset = height
        for i, optionText in ipairs(options) do
            table.insert(dropdownElements, Roact.createElement("TextButton", {
                Size = UDim2.new(1, 0, 0, height),
                Position = UDim2.new(0, 0, 0, yOffset),
                BackgroundColor3 = optionBackgroundColor,
                TextColor3 = textColor,
                Text = optionText,
                Font = Enum.Font.SourceSans,
                TextScaled = true,
                TextXAlignment = Enum.TextXAlignment.Left,
                TextPadding = UDim2.new(0, 10, 0, 0),
                BorderSizePixel = 1,
                BorderColor3 = borderColor,
                [Roact.Event.MouseEnter] = function(rbx)
                    rbx.BackgroundColor3 = optionHoverColor
                end,
                [Roact.Event.MouseLeave] = function(rbx)
                    rbx.BackgroundColor3 = optionBackgroundColor
                end,
                [Roact.Event.MouseButton1Click] = function()
                    self:setState({
                        SelectedOption = optionText,
                        IsOpen = false,
                    })
                    if props.OnChanged then
                        props.OnChanged(optionText)
                    end
                end,
            }))
            yOffset = yOffset + height
        end
    end

    return Roact.createElement("Frame", {
        Size = UDim2.new(0, width, 0, state.IsOpen and (height * (#options + 1)) or height),
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
    }, dropdownElements)
end

-- MultiDropdown Component Definition
local MultiDropdown = Roact.Component:extend("MultiDropdown")

function MultiDropdown:init()
    BaseComponent.init(self)
    self:setState({
        IsOpen = false,
        SelectedOptions = self.props.DefaultValue or {},
    })
end

function MultiDropdown:render()
    local props = self.props
    local state = self.state

    local options = props.Options or {}
    local width = props.Width or 200
    local height = props.Height or 30
    local backgroundColor = props.BackgroundColor or StyleManager:GetColor("InputBackground")
    local textColor = props.TextColor or StyleManager:GetColor("Text")
    local borderColor = props.BorderColor or StyleManager:GetColor("Border")
    local optionBackgroundColor = props.OptionBackgroundColor or StyleManager:GetColor("OptionBackground")
    local optionHoverColor = props.OptionHoverColor or StyleManager:GetColor("OptionHover")
    local selectedOptionColor = props.SelectedOptionColor or StyleManager:GetColor("SelectedOption")

    local dropdownElements = {}

    local displayText = "Select Options..."
    if #state.SelectedOptions > 0 then
        displayText = table.concat(state.SelectedOptions, ", ")
    end

    table.insert(dropdownElements, Roact.createElement("TextButton", {
        Size = UDim2.new(1, 0, 0, height),
        BackgroundColor3 = backgroundColor,
        TextColor3 = textColor,
        Text = displayText,
        Font = Enum.Font.SourceSans,
        TextScaled = true,
        TextXAlignment = Enum.TextXAlignment.Left,
        TextPadding = UDim2.new(0, 10, 0, 0),
        BorderSizePixel = 1,
        BorderColor3 = borderColor,
        [Roact.Event.MouseButton1Click] = function()
            self:setState({ IsOpen = not state.IsOpen })
        end,
    }))

    if state.IsOpen then
        local yOffset = height
        for i, optionText in ipairs(options) do
            local isSelected = false
            for _, selected in ipairs(state.SelectedOptions) do
                if selected == optionText then
                    isSelected = true
                    break
                end
            end

            local currentOptionBgColor = isSelected and selectedOptionColor or optionBackgroundColor

            table.insert(dropdownElements, Roact.createElement("TextButton", {
                Size = UDim2.new(1, 0, 0, height),
                Position = UDim2.new(0, 0, 0, yOffset),
                BackgroundColor3 = currentOptionBgColor,
                TextColor3 = textColor,
                Text = optionText,
                Font = Enum.Font.SourceSans,
                TextScaled = true,
                TextXAlignment = Enum.TextXAlignment.Left,
                TextPadding = UDim2.new(0, 10, 0, 0),
                BorderSizePixel = 1,
                BorderColor3 = borderColor,
                [Roact.Event.MouseEnter] = function(rbx)
                    if not isSelected then
                        rbx.BackgroundColor3 = optionHoverColor
                    end
                end,
                [Roact.Event.MouseLeave] = function(rbx)
                    rbx.BackgroundColor3 = currentOptionBgColor
                end,
                [Roact.Event.MouseButton1Click] = function()
                    local newSelectedOptions = table.clone(state.SelectedOptions)
                    if isSelected then
                        for idx, selected in ipairs(newSelectedOptions) do
                            if selected == optionText then
                                table.remove(newSelectedOptions, idx)
                                break
                            end
                        end
                    else
                        table.insert(newSelectedOptions, optionText)
                    end
                    self:setState({ SelectedOptions = newSelectedOptions })
                    if props.OnChanged then
                        props.OnChanged(newSelectedOptions)
                    end
                end,
            }))
            yOffset = yOffset + height
        end
    end

    return Roact.createElement("Frame", {
        Size = UDim2.new(0, width, 0, state.IsOpen and (height * (#options + 1)) or height),
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
    }, dropdownElements)
end

-- Slider Component Definition
local Slider = Roact.Component:extend("Slider")

function Slider:init()
    BaseComponent.init(self)
    self:setState({
        Value = self.props.DefaultValue or 0,
        IsDragging = false,
    })
end

function Slider:render()
    local props = self.props
    local state = self.state

    local width = props.Width or 200
    local height = props.Height or 20
    local min = props.Min or 0
    local max = props.Max or 100
    local trackColor = props.TrackColor or StyleManager:GetColor("ToggleOff")
    local fillColor = props.FillColor or StyleManager:GetColor("Primary")
    local handleColor = props.HandleColor or StyleManager:GetColor("Handle")
    local borderColor = props.BorderColor or StyleManager:GetColor("Border")

    local normalizedValue = (state.Value - min) / (max - min)
    local fillWidth = normalizedValue * width
    local handlePositionX = normalizedValue * width - (height / 2)

    return Roact.createElement("Frame", {
        Size = UDim2.new(0, width, 0, height),
        BackgroundColor3 = trackColor,
        BorderSizePixel = 1,
        BorderColor3 = borderColor,
        CornerRadius = UDim.new(0.5, 0),
        [Roact.Event.InputBegan] = function(rbx, input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 then
                self:setState({ IsDragging = true })
                local newX = input.Position.X - rbx.AbsolutePosition.X
                local newValue = math.clamp(min + (newX / width) * (max - min), min, max)
                self:setState({ Value = newValue })
                if props.OnChanged then
                    props.OnChanged(newValue)
                end
            end
        end,
        [Roact.Event.InputEnded] = function(rbx, input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 then
                self:setState({ IsDragging = false })
            end
        end,
        [Roact.Event.InputChanged] = function(rbx, input)
            if input.UserInputType == Enum.UserInputType.MouseMovement and state.IsDragging then
                local newX = input.Position.X - rbx.AbsolutePosition.X
                local newValue = math.clamp(min + (newX / width) * (max - min), min, max)
                self:setState({ Value = newValue })
                if props.OnChanged then
                    props.OnChanged(newValue)
                end
            end
        end,
    }, {
        Fill = Roact.createElement("Frame", {
            Size = UDim2.new(0, fillWidth, 1, 0),
            BackgroundColor3 = fillColor,
            BorderSizePixel = 0,
            CornerRadius = UDim.new(0.5, 0),
        }),
        Handle = Roact.createElement("Frame", {
            Size = UDim2.new(0, height, 0, height),
            Position = UDim2.new(0, handlePositionX, 0, 0),
            BackgroundColor3 = handleColor,
            BorderSizePixel = 1,
            BorderColor3 = borderColor,
            CornerRadius = UDim.new(0.5, 0),
        }),
        ValueLabel = Roact.createElement("TextLabel", {
            Size = UDim2.new(0, 50, 1, 0),
            Position = UDim2.new(1, 5, 0, 0),
            BackgroundTransparency = 1,
            Text = string.format("%.0f", state.Value),
            TextColor3 = StyleManager:GetColor("Text"),
            Font = Enum.Font.SourceSans,
            TextScaled = true,
            TextXAlignment = Enum.TextXAlignment.Left,
        }),
    })
end

-- InputSlider Component Definition
local InputSlider = Roact.Component:extend("InputSlider")

function InputSlider:init()
    BaseComponent.init(self)
    self:setState({
        Value = self.props.DefaultValue or 0,
        IsDragging = false,
    })
end

function InputSlider:render()
    local props = self.props
    local state = self.state

    local width = props.Width or 250
    local height = props.Height or 40
    local min = props.Min or 0
    local max = props.Max or 100
    local step = props.Step or 1
    local trackColor = props.TrackColor or StyleManager:GetColor("ToggleOff")
    local fillColor = props.FillColor or StyleManager:GetColor("Primary")
    local handleColor = props.HandleColor or StyleManager:GetColor("Handle")
    local borderColor = props.BorderColor or StyleManager:GetColor("Border")
    local inputBackgroundColor = props.InputBackgroundColor or StyleManager:GetColor("InputBackground")
    local inputTextColor = props.InputTextColor or StyleManager:GetColor("Text")

    local normalizedValue = (state.Value - min) / (max - min)
    local fillWidth = normalizedValue * (width - 50)
    local handlePositionX = normalizedValue * (width - 50) - (height / 2)

    return Roact.createElement("Frame", {
        Size = UDim2.new(0, width, 0, height),
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
    }, {
        InputField = Roact.createElement("TextBox", {
            Size = UDim2.new(0, 50, 1, 0),
            Position = UDim2.new(1, -50, 0, 0),
            BackgroundColor3 = inputBackgroundColor,
            TextColor3 = inputTextColor,
            Text = tostring(math.floor(state.Value / step) * step),
            Font = Enum.Font.SourceSans,
            TextScaled = false,
            TextSize = 14,
            ClearTextOnFocus = false,
            BorderSizePixel = 1,
            BorderColor3 = borderColor,
            [Roact.Event.FocusLost] = function(rbx, enterPressed)
                local newValue = tonumber(rbx.Text)
                if newValue then
                    newValue = math.clamp(math.floor(newValue / step) * step, min, max)
                    self:setState({ Value = newValue })
                    if props.OnChanged then
                        props.OnChanged(newValue)
                    end
                else
                    rbx.Text = tostring(math.floor(state.Value / step) * step)
                end
            end,
            [Roact.Event.Changed] = function(rbx)
            end,
        }),

        SliderTrack = Roact.createElement("Frame", {
            Size = UDim2.new(1, -60, 0, height / 2),
            Position = UDim2.new(0, 0, 0.5, -height / 4),
            BackgroundColor3 = trackColor,
            BorderSizePixel = 1,
            BorderColor3 = borderColor,
            CornerRadius = UDim.new(0.5, 0),
            [Roact.Event.InputBegan] = function(rbx, input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 then
                    self:setState({ IsDragging = true })
                    local newX = input.Position.X - rbx.AbsolutePosition.X
                    local newValue = math.clamp(min + (newX / (width - 60)) * (max - min), min, max)
                    newValue = math.floor(newValue / step) * step
                    self:setState({ Value = newValue })
                    if props.OnChanged then
                        props.OnChanged(newValue)
                    end
                end
            end,
            [Roact.Event.InputEnded] = function(rbx, input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 then
                    self:setState({ IsDragging = false })
                end
            end,
            [Roact.Event.InputChanged] = function(rbx, input)
                if input.UserInputType == Enum.UserInputType.MouseMovement and state.IsDragging then
                    local newX = input.Position.X - rbx.AbsolutePosition.X
                    local newValue = math.clamp(min + (newX / (width - 60)) * (max - min), min, max)
                    newValue = math.floor(newValue / step) * step
                    self:setState({ Value = newValue })
                    if props.OnChanged then
                        props.OnChanged(newValue)
                    end
                end
            end,
        }, {
            Fill = Roact.createElement("Frame", {
                Size = UDim2.new(0, fillWidth, 1, 0),
                BackgroundColor3 = fillColor,
                BorderSizePixel = 0,
                CornerRadius = UDim.new(0.5, 0),
            }),
            Handle = Roact.createElement("Frame", {
                Size = UDim2.new(0, height / 2, 0, height / 2),
                Position = UDim2.new(0, handlePositionX, 0.5, 0),
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundColor3 = handleColor,
                BorderSizePixel = 1,
                BorderColor3 = borderColor,
                CornerRadius = UDim.new(0.5, 0),
            }),
        }),
    })
end

-- ColorPicker Component Definition
local ColorPicker = Roact.Component:extend("ColorPicker")

function ColorPicker:init()
    BaseComponent.init(self)
    self:setState({
        SelectedColor = self.props.DefaultValue or Color3.new(1, 0, 0),
        IsPicking = false,
        Hue = 0,
        Saturation = 1,
        Value = 1,
    })
    self:updateHSVFromColor(self.state.SelectedColor)
end

function ColorPicker:updateHSVFromColor(color)
    local h, s, v = color:ToHSV()
    self:setState({
        Hue = h * 360,
        Saturation = s,
        Value = v,
    })
end

function ColorPicker:render()
    local props = self.props
    local state = self.state

    local width = props.Width or 200
    local height = props.Height or 200
    local previewSize = props.PreviewSize or 30
    local borderColor = props.BorderColor or StyleManager:GetColor("Border")

    local h = state.Hue / 360
    local s = state.Saturation
    local v = state.Value

    local currentColor = Color3.fromHSV(h, s, v)

    return Roact.createElement("Frame", {
        Size = UDim2.new(0, width, 0, height + previewSize + 10),
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
    }, {
        ColorPreview = Roact.createElement("Frame", {
            Size = UDim2.new(0, previewSize, 0, previewSize),
            Position = UDim2.new(0, 0, 0, 0),
            BackgroundColor3 = currentColor,
            BorderSizePixel = 1,
            BorderColor3 = borderColor,
        }),

        ColorArea = Roact.createElement("Frame", {
            Size = UDim2.new(1, 0, 0, height),
            Position = UDim2.new(0, 0, 0, previewSize + 5),
            BackgroundColor3 = Color3.new(1, 1, 1),
            BorderSizePixel = 1,
            BorderColor3 = borderColor,
            [Roact.Event.InputBegan] = function(rbx, input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 then
                    self:setState({ IsPicking = true })
                    local x = math.clamp((input.Position.X - rbx.AbsolutePosition.X) / rbx.AbsoluteSize.X, 0, 1)
                    local y = math.clamp((input.Position.Y - rbx.AbsolutePosition.Y) / rbx.AbsoluteSize.Y, 0, 1)
                    local newHue = x * 360
                    local newSaturation = 1 - y
                    local newColor = Color3.fromHSV(newHue / 360, newSaturation, state.Value)
                    self:setState({ Hue = newHue, Saturation = newSaturation, SelectedColor = newColor })
                    if props.OnChanged then
                        props.OnChanged(newColor)
                    end
                end
            end,
            [Roact.Event.InputEnded] = function(rbx, input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 then
                    self:setState({ IsPicking = false })
                end
            end,
            [Roact.Event.InputChanged] = function(rbx, input)
                if input.UserInputType == Enum.UserInputType.MouseMovement and state.IsPicking then
                    local x = math.clamp((input.Position.X - rbx.AbsolutePosition.X) / rbx.AbsoluteSize.X, 0, 1)
                    local y = math.clamp((input.Position.Y - rbx.AbsolutePosition.Y) / rbx.AbsoluteSize.Y, 0, 1)
                    local newHue = x * 360
                    local newSaturation = 1 - y
                    local newColor = Color3.fromHSV(newHue / 360, newSaturation, state.Value)
                    self:setState({ Hue = newHue, Saturation = newSaturation, SelectedColor = newColor })
                    if props.OnChanged then
                        props.OnChanged(newColor)
                    end
                end
            end,
        }, {
            HueGradient = Roact.createElement("UIGradient", {
                Color = ColorSequence.new({
                    ColorSequenceKeypoint.new(0, Color3.fromHSV(0, 1, 1)),
                    ColorSequenceKeypoint.new(1/6, Color3.fromHSV(1/6, 1, 1)),
                    ColorSequenceKeypoint.new(2/6, Color3.fromHSV(2/6, 1, 1)),
                    ColorSequenceKeypoint.new(3/6, Color3.fromHSV(3/6, 1, 1)),
                    ColorSequenceKeypoint.new(4/6, Color3.fromHSV(4/6, 1, 1)),
                    ColorSequenceKeypoint.new(5/6, Color3.fromHSV(5/6, 1, 1)),
                    ColorSequenceKeypoint.new(1, Color3.fromHSV(1, 1, 1)),
                }),
                Rotation = 0,
            }),
            SaturationValueGradient = Roact.createElement("UIGradient", {
                Color = ColorSequence.new({
                    ColorSequenceKeypoint.new(0, Color3.new(1, 1, 1)),
                    ColorSequenceKeypoint.new(1, Color3.new(0, 0, 0)),
                }),
                Rotation = 90,
            }),
        }),

        ValueSlider = Roact.createElement(Slider, {
            Size = UDim2.new(1, 0, 0, 20),
            Position = UDim2.new(0, 0, 0, height + previewSize + 10 - 20),
            Min = 0,
            Max = 1,
            Step = 0.01,
            DefaultValue = state.Value,
            OnChanged = function(newValue)
                local newColor = Color3.fromHSV(h, s, newValue)
                self:setState({ Value = newValue, SelectedColor = newColor })
                if props.OnChanged then
                    props.OnChanged(newColor)
                end
            end,
            TrackColor = StyleManager:GetColor("ToggleOff"),
            FillColor = currentColor,
            HandleColor = StyleManager:GetColor("Handle"),
            BorderColor = StyleManager:GetColor("Border"),
        }),
    })
end

-- Paragraph Component Definition
local Paragraph = Roact.Component:extend("Paragraph")

function Paragraph:render()
    local props = self.props

    local text = props.Text or ""
    local textColor = props.TextColor or StyleManager:GetColor("Text")
    local textSize = props.TextSize or 14
    local font = props.Font or Enum.Font.SourceSans
    local size = props.Size or UDim2.new(1, 0, 0, 50)
    local textXAlignment = props.TextXAlignment or Enum.TextXAlignment.Left
    local textYAlignment = props.TextYAlignment or Enum.TextYAlignment.Top

    return Roact.createElement("TextLabel", {
        Size = size,
        BackgroundTransparency = 1,
        Text = text,
        TextColor3 = textColor,
        TextSize = textSize,
        Font = font,
        TextWrapped = true,
        TextXAlignment = textXAlignment,
        TextYAlignment = textYAlignment,
    })
end

-- ImageParagraph Component Definition
local ImageParagraph = Roact.Component:extend("ImageParagraph")

function ImageParagraph:render()
    local props = self.props

    local imageUrl = props.ImageUrl or ""
    local text = props.Text or ""
    local textColor = props.TextColor or StyleManager:GetColor("Text")
    local textSize = props.TextSize or 14
    local font = props.Font or Enum.Font.SourceSans
    local imageSize = props.ImageSize or UDim2.new(0, 50, 0, 50)
    local layoutDirection = props.LayoutDirection or "Horizontal"

    local children = {}

    if layoutDirection == "Horizontal" then
        table.insert(children, Roact.createElement("ImageLabel", {
            Size = imageSize,
            Image = imageUrl,
            BackgroundTransparency = 1,
            ScaleType = Enum.ScaleType.Fit,
        }))
        table.insert(children, Roact.createElement("TextLabel", {
            Size = UDim2.new(1, -imageSize.X.Offset, 1, 0),
            Position = UDim2.new(0, imageSize.X.Offset, 0, 0),
            BackgroundTransparency = 1,
            Text = text,
            TextColor3 = textColor,
            TextSize = textSize,
            Font = font,
            TextWrapped = true,
            TextXAlignment = Enum.TextXAlignment.Left,
            TextYAlignment = Enum.TextYAlignment.Top,
        }))
    else
        table.insert(children, Roact.createElement("ImageLabel", {
            Size = imageSize,
            Image = imageUrl,
            BackgroundTransparency = 1,
            ScaleType = Enum.ScaleType.Fit,
        }))
        table.insert(children, Roact.createElement("TextLabel", {
            Size = UDim2.new(1, 0, 1, -imageSize.Y.Offset),
            Position = UDim2.new(0, 0, 0, imageSize.Y.Offset),
            BackgroundTransparency = 1,
            Text = text,
            TextColor3 = textColor,
            TextSize = textSize,
            Font = font,
            TextWrapped = true,
            TextXAlignment = Enum.TextXAlignment.Left,
            TextYAlignment = Enum.TextYAlignment.Top,
        }))
    end

    return Roact.createElement("Frame", {
        Size = props.Size or UDim2.new(1, 0, 0, 100),
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
    }, children)
end

-- Window Component Definition
local Window = Roact.Component:extend("Window")

function Window:init()
    BaseComponent.init(self)
    self:setState({
        isDragging = false,
        startPosition = Vector2.new(0, 0),
        startMousePosition = Vector2.new(0, 0),
        isLocked = self.props.IsLocked or false,
        isResizing = false,
        resizeStartMousePosition = Vector2.new(0, 0),
        resizeStartSize = UDim2.new(0, 0, 0, 0),
    })
end

function Window:render()
    local props = self.props
    local state = self.state

    local size = props.Size or UDim2.new(0, 600, 0, 400)
    local position = props.Position or UDim2.new(0.5, 0, 0.5, 0)
    local anchorPoint = props.AnchorPoint or Vector2.new(0.5, 0.5)
    local backgroundColor = props.BackgroundColor or StyleManager:GetColor("Secondary")
    local title = props.Title or "UI Window"

    return Roact.createElement("Frame", {
        Size = size,
        Position = position,
        AnchorPoint = anchorPoint,
        BackgroundColor3 = backgroundColor,
        BorderSizePixel = 0,
        [Roact.Event.InputBegan] = function(rbx, input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 and not state.isLocked then
                local mousePos = input.Position
                local rbxPos = rbx.AbsolutePosition
                local rbxSize = rbx.AbsoluteSize

                if mousePos.X > rbxPos.X + rbxSize.X - 10 and mousePos.Y > rbxPos.Y + rbxSize.Y - 10 then
                    self:setState({
                        isResizing = true,
                        resizeStartMousePosition = mousePos,
                        resizeStartSize = rbx.Size,
                    })
                else
                    self:setState({
                        isDragging = true,
                        startPosition = rbx.AbsolutePosition,
                        startMousePosition = mousePos,
                    })
                end
            end
        end,
        [Roact.Event.InputEnded] = function(rbx, input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 then
                self:setState({ isDragging = false, isResizing = false })
            end
        end,
        [Roact.Event.InputChanged] = function(rbx, input)
            if input.UserInputType == Enum.UserInputType.MouseMovement then
                if state.isDragging and not state.isLocked then
                    local delta = input.Position - state.startMousePosition
                    local newX = state.startPosition.X + delta.X
                    local newY = state.startPosition.Y + delta.Y
                    rbx.Position = UDim2.new(0, newX, 0, newY)
                elseif state.isResizing then
                    local delta = input.Position - state.resizeStartMousePosition
                    local newWidth = math.max(100, state.resizeStartSize.X.Offset + delta.X)
                    local newHeight = math.max(100, state.resizeStartSize.Y.Offset + delta.Y)
                    rbx.Size = UDim2.new(0, newWidth, 0, newHeight)
                end
            end
        end,
    }, {
        TitleBar = Roact.createElement("Frame", {
            Size = UDim2.new(1, 0, 0, 30),
            Position = UDim2.new(0, 0, 0, 0),
            BackgroundColor3 = StyleManager:GetColor("Background"),
            BorderSizePixel = 0,
        }, {
            TitleLabel = Roact.createElement("TextLabel", {
                Size = UDim2.new(1, -60, 1, 0),
                Position = UDim2.new(0, 10, 0, 0),
                BackgroundColor3 = StyleManager:GetColor("Background"),
                BackgroundTransparency = 1,
                Text = title,
                TextColor3 = StyleManager:GetColor("Text"),
                TextScaled = true,
                Font = Enum.Font.SourceSansBold,
                TextXAlignment = Enum.TextXAlignment.Left,
            }),
        }),
        Content = Roact.createElement("Frame", {
            Size = UDim2.new(1, 0, 1, -30),
            Position = UDim2.new(0, 0, 0, 30),
            BackgroundColor3 = backgroundColor,
            BackgroundTransparency = 1,
            BorderSizePixel = 0,
        }, props[Roact.Children]),

        ResizeHandle = Roact.createElement("Frame", {
            Size = UDim2.new(0, 10, 0, 10),
            Position = UDim2.new(1, -10, 1, -10),
            AnchorPoint = Vector2.new(1, 1),
            BackgroundColor3 = StyleManager:GetColor("Border"),
            BorderSizePixel = 0,
            ZIndex = 2,
        }),
    })
end

-- Tabs Component Definition
local Tabs = Roact.Component:extend("Tabs")

function Tabs:init()
    BaseComponent.init(self)
    self:setState({
        ActiveTab = self.props.DefaultTab or (self.props.Tabs and self.props.Tabs[1].Name) or "",
    })
end

function Tabs:render()
    local props = self.props
    local state = self.state

    local tabs = props.Tabs or {}
    local tabButtonHeight = props.TabButtonHeight or 30
    local tabButtonColor = props.TabButtonColor or StyleManager:GetColor("InputBackground")
    local activeTabButtonColor = props.ActiveTabButtonColor or StyleManager:GetColor("Secondary")
    local textColor = props.TextColor or StyleManager:GetColor("Text")
    local contentBackgroundColor = props.ContentBackgroundColor or StyleManager:GetColor("Secondary")

    local tabButtons = {}
    local currentContent = nil

    for i, tab in ipairs(tabs) do
        local isSelected = (tab.Name == state.ActiveTab)
        local buttonColor = isSelected and activeTabButtonColor or tabButtonColor

        table.insert(tabButtons, Roact.createElement("TextButton", {
            Size = UDim2.new(1, 0, 0, tabButtonHeight),
            Position = UDim2.new(0, 0, 0, (i - 1) * tabButtonHeight),
            BackgroundColor3 = buttonColor,
            TextColor3 = textColor,
            Text = tab.Name,
            Font = Enum.Font.SourceSansBold,
            TextScaled = true,
            BorderSizePixel = 0,
            [Roact.Event.MouseButton1Click] = function()
                self:setState({ ActiveTab = tab.Name })
            end,
        }))

        if isSelected then
            currentContent = tab.Content
        end
    end

    return Roact.createElement("Frame", {
        Size = props.Size or UDim2.new(1, 0, 1, 0),
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
    }, {
        TabButtonsFrame = Roact.createElement("Frame", {
            Size = UDim2.new(0.2, 0, 1, 0),
            BackgroundColor3 = tabButtonColor,
            BorderSizePixel = 0,
        }, tabButtons),

        TabContentFrame = Roact.createElement("Frame", {
            Size = UDim2.new(0.8, 0, 1, 0),
            Position = UDim2.new(0.2, 0, 0, 0),
            BackgroundColor3 = contentBackgroundColor,
            BorderSizePixel = 0,
        }, {
            Content = currentContent,
        }),
    })
end

-- Main AXS Component (Top-level UI)
local AXS = Roact.Component:extend("AXS")

function AXS:init()
    self:setState({
        IsUIHidden = false,
        IsUILocked = false,
    })
end

function AXS:render()
    local state = self.state

    return Roact.createElement("ScreenGui", {
        IgnoreGuiInset = true,
        Enabled = not state.IsUIHidden,
    }, {
        ToggleButton = Roact.createElement(Button, {
            Text = state.IsUIHidden and "Show UI" or "Hide UI",
            Size = UDim2.new(0, 80, 0, 30),
            Position = UDim2.new(0, 10, 0, 10),
            BackgroundColor = StyleManager:GetColor("Primary"),
            TextColor = StyleManager:GetColor("Text"),
            OnActivated = function()
                self:setState({ IsUIHidden = not state.IsUIHidden })
            end,
        }),

        LockButton = Roact.createElement(Button, {
            Text = state.IsUILocked and "Unlock UI" or "Lock UI",
            Size = UDim2.new(0, 80, 0, 30),
            Position = UDim2.new(0, 10, 0, 50),
            BackgroundColor = StyleManager:GetColor("Primary"),
            TextColor = StyleManager:GetColor("Text"),
            OnActivated = function()
                self:setState({ IsUILocked = not state.IsUILocked })
            end,
        }),

        MainWindow = Roact.createElement(Window, {
            Title = "AX-SCRIPTS",
            Size = UDim2.new(0, 600, 0, 400),
            Position = UDim2.new(0.5, 0, 0.5, 0),
            AnchorPoint = Vector2.new(0.5, 0.5),
            IsLocked = state.IsUILocked,
            [Roact.Children] = {
                Roact.createElement(Tabs, {
                    Size = UDim2.new(1, 0, 1, 0),
                    Tabs = {
                        {Name = "Games", Content = Roact.createElement("Frame", {BackgroundTransparency = 1}, {
                            Roact.createElement(Toggle, {Text = "God Mode", DefaultValue = false, Position = UDim2.new(0, 10, 0, 10)}),
                            Roact.createElement(Button, {Text = "Finish Red Light, Green Light", Position = UDim2.new(0, 10, 0, 50)}),
                            Roact.createElement(Input, {PlaceholderText = "Select Injured Player", Position = UDim2.new(0, 10, 0, 90)}),
                            Roact.createElement(Dropdown, {Options = {"Option 1", "Option 2"}, Position = UDim2.new(0, 10, 0, 130)}),
                            Roact.createElement(MultiDropdown, {Options = {"Multi 1", "Multi 2"}, Position = UDim2.new(0, 10, 0, 170)}),
                            Roact.createElement(Slider, {Min = 0, Max = 100, DefaultValue = 50, Position = UDim2.new(0, 10, 0, 210)}),
                            Roact.createElement(InputSlider, {Min = 0, Max = 100, DefaultValue = 25, Step = 5, Position = UDim2.new(0, 10, 0, 250)}),
                            Roact.createElement(ColorPicker, {Position = UDim2.new(0, 10, 0, 290)}),
                            Roact.createElement(Paragraph, {Text = "This is a sample paragraph for demonstration purposes.", Position = UDim2.new(0, 10, 0, 500)}),
                            Roact.createElement(ImageParagraph, {ImageUrl = "rbxassetid://123456789", Text = "Image with text example.", Position = UDim2.new(0, 10, 0, 560)}),
                        })},
                        {Name = "Settings", Content = Roact.createElement("Frame", {BackgroundTransparency = 1}, {
                            Roact.createElement(Toggle, {Text = "Option A", DefaultValue = true, Position = UDim2.new(0, 10, 0, 10)}),
                            Roact.createElement(Input, {PlaceholderText = "Setting Value", Position = UDim2.new(0, 10, 0, 50)}),
                        })},
                    }
                }),
            }
        }),
    })
end

return AXS


