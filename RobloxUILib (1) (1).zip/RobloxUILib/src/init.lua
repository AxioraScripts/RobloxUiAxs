--!strict

local RobloxUILib = {}

-- Define the Roact dependency
local Roact = require(game.ReplicatedStorage.Roact)

-- Export Roact for convenience
RobloxUILib.Roact = Roact

-- Load components
RobloxUILib.Components = {}

-- Load utilities
RobloxUILib.Utilities = {}

-- Load styles
RobloxUILib.Styles = {}

return RobloxUILib




RobloxUILib.Components.Button = require(script.Components.Button)
RobloxUILib.Components.Toggle = require(script.Components.Toggle)
RobloxUILib.Components.Input = require(script.Components.Input)
RobloxUILib.Components.Dropdown = require(script.Components.Dropdown)
RobloxUILib.Components.Slider = require(script.Components.Slider)
RobloxUILib.Components.Window = require(script.Components.Window)
RobloxUILib.Components.Tabs = require(script.Components.Tabs)




RobloxUILib.Components.MultiDropdown = require(script.Components.MultiDropdown)
RobloxUILib.Components.InputSlider = require(script.Components.InputSlider)
RobloxUILib.Components.ColorPicker = require(script.Components.ColorPicker)
RobloxUILib.Components.Paragraph = require(script.Components.Paragraph)
RobloxUILib.Components.ImageParagraph = require(script.Components.ImageParagraph)




RobloxUILib.Styles.StyleManager = require(script.Styles.StyleManager)


