--!strict

local Roact = require(script.Parent.Parent.init).Roact
local BaseComponent = require(script.Parent.BaseComponent)

local Slider = Roact.Component:extend("Slider")

function Slider:init()
    BaseComponent.init(self)
    self:setState({
        Value = self.props.DefaultValue or 0,
        IsDragging = false,
    })
end

function Slider:render()
    local props = self.props
    local state = self.state

    local width = props.Width or 200
    local height = props.Height or 20
    local min = props.Min or 0
    local max = props.Max or 100
    local trackColor = props.TrackColor or Color3.new(0.3, 0.3, 0.3)
    local fillColor = props.FillColor or Color3.new(0.2, 0.6, 0.8)
    local handleColor = props.HandleColor or Color3.new(1, 1, 1)
    local borderColor = props.BorderColor or Color3.new(0.1, 0.1, 0.1)

    local normalizedValue = (state.Value - min) / (max - min)
    local fillWidth = normalizedValue * width
    local handlePositionX = normalizedValue * width - (height / 2) -- Center handle

    return Roact.createElement("Frame", {
        Size = UDim2.new(0, width, 0, height),
        BackgroundColor3 = trackColor,
        BorderSizePixel = 1,
        BorderColor3 = borderColor,
        CornerRadius = UDim.new(0.5, 0),
        [Roact.Event.InputBegan] = function(rbx, input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 then
                self:setState({ IsDragging = true })
                local newX = input.Position.X - rbx.AbsolutePosition.X
                local newValue = math.clamp(min + (newX / width) * (max - min), min, max)
                self:setState({ Value = newValue })
                if props.OnChanged then
                    props.OnChanged(newValue)
                end
            end
        end,
        [Roact.Event.InputEnded] = function(rbx, input)
            if input.UserInputType == Enum.UserInputType.MouseButton1 then
                self:setState({ IsDragging = false })
            end
        end,
        [Roact.Event.InputChanged] = function(rbx, input)
            if input.UserInputType == Enum.UserInputType.MouseMovement and state.IsDragging then
                local newX = input.Position.X - rbx.AbsolutePosition.X
                local newValue = math.clamp(min + (newX / width) * (max - min), min, max)
                self:setState({ Value = newValue })
                if props.OnChanged then
                    props.OnChanged(newValue)
                end
            end
        end,
    }, {
        Fill = Roact.createElement("Frame", {
            Size = UDim2.new(0, fillWidth, 1, 0),
            BackgroundColor3 = fillColor,
            BorderSizePixel = 0,
            CornerRadius = UDim.new(0.5, 0),
        }),
        Handle = Roact.createElement("Frame", {
            Size = UDim2.new(0, height, 0, height), -- Handle is square
            Position = UDim2.new(0, handlePositionX, 0, 0),
            BackgroundColor3 = handleColor,
            BorderSizePixel = 1,
            BorderColor3 = borderColor,
            CornerRadius = UDim.new(0.5, 0),
        }),
        ValueLabel = Roact.createElement("TextLabel", {
            Size = UDim2.new(0, 50, 1, 0),
            Position = UDim2.new(1, 5, 0, 0),
            BackgroundTransparency = 1,
            Text = string.format("%.0f", state.Value),
            TextColor3 = Color3.new(1, 1, 1),
            Font = Enum.Font.SourceSans,
            TextScaled = true,
            TextXAlignment = Enum.TextXAlignment.Left,
        }),
    })
end

return Slider


