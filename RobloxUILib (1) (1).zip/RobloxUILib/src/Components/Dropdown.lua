--!strict

local Roact = require(script.Parent.Parent.init).Roact
local BaseComponent = require(script.Parent.BaseComponent)

local Dropdown = Roact.Component:extend("Dropdown")

function Dropdown:init()
    BaseComponent.init(self)
    self:setState({
        IsOpen = false,
        SelectedOption = self.props.DefaultValue or (self.props.Options and self.props.Options[1]) or "",
    })
end

function Dropdown:render()
    local props = self.props
    local state = self.state

    local options = props.Options or {}
    local width = props.Width or 200
    local height = props.Height or 30
    local backgroundColor = props.BackgroundColor or Color3.new(0.2, 0.2, 0.2)
    local textColor = props.TextColor or Color3.new(1, 1, 1)
    local borderColor = props.BorderColor or Color3.new(0.1, 0.1, 0.1)
    local optionBackgroundColor = props.OptionBackgroundColor or Color3.new(0.25, 0.25, 0.25)
    local optionHoverColor = props.OptionHoverColor or Color3.new(0.3, 0.3, 0.3)

    local dropdownElements = {}

    -- Selected option display
    table.insert(dropdownElements, Roact.createElement("TextButton", {
        Size = UDim2.new(1, 0, 0, height),
        BackgroundColor3 = backgroundColor,
        TextColor3 = textColor,
        Text = state.SelectedOption,
        Font = Enum.Font.SourceSans,
        TextScaled = true,
        TextXAlignment = Enum.TextXAlignment.Left,
        TextPadding = UDim2.new(0, 10, 0, 0),
        BorderSizePixel = 1,
        BorderColor3 = borderColor,
        [Roact.Event.MouseButton1Click] = function()
            self:setState({ IsOpen = not state.IsOpen })
        end,
    }))

    -- Dropdown options list
    if state.IsOpen then
        local yOffset = height
        for i, optionText in ipairs(options) do
            table.insert(dropdownElements, Roact.createElement("TextButton", {
                Size = UDim2.new(1, 0, 0, height),
                Position = UDim2.new(0, 0, 0, yOffset),
                BackgroundColor3 = optionBackgroundColor,
                TextColor3 = textColor,
                Text = optionText,
                Font = Enum.Font.SourceSans,
                TextScaled = true,
                TextXAlignment = Enum.TextXAlignment.Left,
                TextPadding = UDim2.new(0, 10, 0, 0),
                BorderSizePixel = 1,
                BorderColor3 = borderColor,
                [Roact.Event.MouseEnter] = function(rbx)
                    rbx.BackgroundColor3 = optionHoverColor
                end,
                [Roact.Event.MouseLeave] = function(rbx)
                    rbx.BackgroundColor3 = optionBackgroundColor
                end,
                [Roact.Event.MouseButton1Click] = function()
                    self:setState({
                        SelectedOption = optionText,
                        IsOpen = false,
                    })
                    if props.OnChanged then
                        props.OnChanged(optionText)
                    end
                end,
            }))
            yOffset = yOffset + height
        end
    end

    return Roact.createElement("Frame", {
        Size = UDim2.new(0, width, 0, state.IsOpen and (height * (#options + 1)) or height), -- Adjust height based on open state
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
    }, dropdownElements)
end

return Dropdown


