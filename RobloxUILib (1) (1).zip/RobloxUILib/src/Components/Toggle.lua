--!strict

local Roact = require(script.Parent.Parent.init).Roact
local BaseComponent = require(script.Parent.BaseComponent)

local Toggle = Roact.Component:extend("Toggle")

function Toggle:init()
    BaseComponent.init(self)
    self:setState({
        IsOn = self.props.DefaultValue or false,
    })
end

function Toggle:render()
    local props = self.props
    local state = self.state

    local width = props.Width or 60
    local height = props.Height or 30
    local backgroundColorOff = props.BackgroundColorOff or Color3.new(0.3, 0.3, 0.3) -- Grey when off
    local backgroundColorOn = props.BackgroundColorOn or Color3.new(0.2, 0.6, 0.8) -- Blue when on
    local handleColor = props.HandleColor or Color3.new(1, 1, 1) -- White handle
    local borderColor = props.BorderColor or Color3.new(0.1, 0.1, 0.1)
    local text = props.Text or "Toggle"

    local currentBackgroundColor = state.IsOn and backgroundColorOn or backgroundColorOff
    local handlePositionX = state.IsOn and (width - height + 5) or 5 -- Adjust handle position

    return Roact.createElement("Frame", {
        Size = UDim2.new(0, width, 0, height),
        BackgroundColor3 = currentBackgroundColor,
        BorderSizePixel = 1,
        BorderColor3 = borderColor,
        CornerRadius = UDim.new(0.5, 0), -- Rounded corners for the toggle track
        [Roact.Event.MouseButton1Click] = function()
            self:setState({ IsOn = not state.IsOn })
            if props.OnChanged then
                props.OnChanged(not state.IsOn)
            end
        end,
    }, {
        Handle = Roact.createElement("Frame", {
            Size = UDim2.new(0, height - 10, 0, height - 10), -- Handle size
            Position = UDim2.new(0, handlePositionX, 0.5, 0), -- Handle position
            AnchorPoint = Vector2.new(0, 0.5),
            BackgroundColor3 = handleColor,
            BorderSizePixel = 0,
            CornerRadius = UDim.new(0.5, 0), -- Rounded handle
        }),
        Label = Roact.createElement("TextLabel", {
            Size = UDim2.new(1, -width, 1, 0),
            Position = UDim2.new(0, width + 5, 0, 0),
            BackgroundTransparency = 1,
            Text = text,
            TextColor3 = Color3.new(1, 1, 1),
            TextScaled = true,
            Font = Enum.Font.SourceSans,
            TextXAlignment = Enum.TextXAlignment.Left,
        }),
    })
end

return Toggle


