--!strict

local Roact = require(script.Parent.Parent.init).Roact
local BaseComponent = require(script.Parent.BaseComponent)

local Input = Roact.Component:extend("Input")

function Input:init()
    BaseComponent.init(self)
    self:setState({
        Text = self.props.DefaultValue or "",
    })
end

function Input:render()
    local props = self.props
    local state = self.state

    local size = props.Size or UDim2.new(1, 0, 0, 30)
    local placeholderText = props.PlaceholderText or "Enter text..."
    local backgroundColor = props.BackgroundColor or Color3.new(0.2, 0.2, 0.2)
    local textColor = props.TextColor or Color3.new(1, 1, 1)
    local borderColor = props.BorderColor or Color3.new(0.1, 0.1, 0.1)

    return Roact.createElement("TextBox", {
        Size = size,
        BackgroundColor3 = backgroundColor,
        TextColor3 = textColor,
        PlaceholderText = placeholderText,
        Text = state.Text,
        Font = Enum.Font.SourceSans,
        TextScaled = false,
        TextSize = 14,
        ClearTextOnFocus = false,
        BorderSizePixel = 1,
        BorderColor3 = borderColor,
        [Roact.Event.Focused] = function(rbx)
            -- Optional: Change style on focus
        end,
        [Roact.Event.FocusLost] = function(rbx, enterPressed)
            if props.OnFocusLost then
                props.OnFocusLost(rbx.Text, enterPressed)
            end
        end,
        [Roact.Event.Changed] = function(rbx)
            self:setState({ Text = rbx.Text })
            if props.OnChanged then
                props.OnChanged(rbx.Text)
            end
        end,
    })
end

return Input


