# AXS UI Library for Roblox

AXS is a comprehensive and customizable UI library for Roblox, built with [Roact](https://roblox.github.io/roact/). It provides a set of reusable UI components, a flexible styling system, and features like draggable and resizable windows.

## Features:

*   **Component-Based:** Built with Roact for modularity and reusability.
*   **Customizable Styling:** Easily change UI colors and themes.
*   **Draggable & Resizable Windows:** Intuitive interaction with UI elements.
*   **Essential UI Elements:** Includes Toggle, Button, Input, Dropdown, MultiDropdown, Slider, InputSlider, ColorPicker, Paragraph, and ImageParagraph.
*   **Loadstring Distribution:** Designed for easy distribution and integration into your Roblox projects.

## Installation & Usage:

To use the AXS UI Library in your Roblox project, you can load it via a loadstring. This is particularly useful for distributing your UI without requiring users to insert models or files directly.

1.  **Host `AXS.lua`:** Upload the `AXS.lua` file (found in the `src` directory) to a platform that provides a raw URL, such as GitHub Gist or a raw GitHub file.

2.  **Load via `loadstring`:** In your Roblox Studio script (e.g., a `LocalScript` in `StarterPlayerScripts`), use the following code to load and initialize the UI library:

    ```lua
    --!strict

    local ReplicatedStorage = game:GetService("ReplicatedStorage")
    local Players = game:GetService("Players")
    local LocalPlayer = Players.LocalPlayer

    -- Replace 'YOUR_GITHUB_RAW_URL_HERE' with the actual raw URL of your AXS.lua file
    local AXS_Loader = loadstring(game:HttpGet("YOUR_GITHUB_RAW_URL_HERE"))
    local AXS = AXS_Loader() -- Execute the loaded string to get the AXS module

    -- Mount the main AXS UI component to the PlayerGui
    Roact.mount(Roact.createElement(AXS), LocalPlayer.PlayerGui, "AXS_UI")

    print("AXS UI Library loaded and mounted.")

    -- Example: Changing the theme to 'Light'
    -- AXS.StyleManager:SetTheme("Light")
    ```

## Components:

### `AXS` (Main Component)

This is the top-level component that manages the overall UI visibility and lock state. It contains the main `Window` and global `Toggle` and `Lock` buttons.

### `Window`

A draggable and resizable container for other UI elements. It includes a title bar.

**Props:**

*   `Title` (string): The title displayed in the window's title bar.
*   `Size` (UDim2): Initial size of the window.
*   `Position` (UDim2): Initial position of the window.
*   `AnchorPoint` (Vector2): Anchor point for positioning.
*   `BackgroundColor` (Color3): Background color of the window content area.
*   `IsLocked` (boolean): If `true`, the window cannot be dragged.

### `Button`

A standard clickable button.

**Props:**

*   `Text` (string): Text displayed on the button.
*   `Size` (UDim2): Size of the button.
*   `Position` (UDim2): Position of the button.
*   `BackgroundColor` (Color3): Background color of the button.
*   `TextColor` (Color3): Text color of the button.
*   `OnActivated` (function): Callback function triggered when the button is clicked.

### `Toggle`

A switch for boolean (on/off) options.

**Props:**

*   `Text` (string): Label for the toggle.
*   `DefaultValue` (boolean): Initial state of the toggle (`true` for on, `false` for off).
*   `Width` (number): Width of the toggle control.
*   `Height` (number): Height of the toggle control.
*   `BackgroundColorOff` (Color3): Background color when off.
*   `BackgroundColorOn` (Color3): Background color when on.
*   `HandleColor` (Color3): Color of the toggle handle.
*   `BorderColor` (Color3): Border color of the toggle.
*   `OnChanged` (function): Callback function triggered when the toggle state changes. Receives the new boolean state as an argument.

### `Input`

A text input field.

**Props:**

*   `DefaultValue` (string): Initial text in the input field.
*   `PlaceholderText` (string): Text displayed when the input is empty.
*   `Size` (UDim2): Size of the input field.
*   `BackgroundColor` (Color3): Background color of the input field.
*   `TextColor` (Color3): Text color of the input field.
*   `BorderColor` (Color3): Border color of the input field.
*   `OnChanged` (function): Callback function triggered when the text changes. Receives the current text as an argument.
*   `OnFocusLost` (function): Callback function triggered when the input field loses focus. Receives the final text and a boolean indicating if Enter was pressed.

### `Dropdown`

A single-selection dropdown menu.

**Props:**

*   `Options` (table of strings): List of available options.
*   `DefaultValue` (string): The initially selected option.
*   `Width` (number): Width of the dropdown.
*   `Height` (number): Height of each option.
*   `BackgroundColor` (Color3): Background color of the dropdown button.
*   `TextColor` (Color3): Text color of the selected option.
*   `BorderColor` (Color3): Border color.
*   `OptionBackgroundColor` (Color3): Background color of dropdown options.
*   `OptionHoverColor` (Color3): Background color of options on hover.
*   `OnChanged` (function): Callback function triggered when a new option is selected. Receives the selected option string.

### `MultiDropdown`

A multi-selection dropdown menu.

**Props:**

*   `Options` (table of strings): List of available options.
*   `DefaultValue` (table of strings): A table of initially selected options.
*   `Width` (number): Width of the multi-dropdown.
*   `Height` (number): Height of each option.
*   `BackgroundColor` (Color3): Background color of the multi-dropdown button.
*   `TextColor` (Color3): Text color of the displayed selected options.
*   `BorderColor` (Color3): Border color.
*   `OptionBackgroundColor` (Color3): Background color of dropdown options.
*   `OptionHoverColor` (Color3): Background color of options on hover.
*   `SelectedOptionColor` (Color3): Background color of selected options.
*   `OnChanged` (function): Callback function triggered when selections change. Receives a table of currently selected options.

### `Slider`

A slider for selecting a numerical value within a range.

**Props:**

*   `Min` (number): Minimum value of the slider.
*   `Max` (number): Maximum value of the slider.
*   `DefaultValue` (number): Initial value of the slider.
*   `Width` (number): Width of the slider.
*   `Height` (number): Height of the slider track.
*   `TrackColor` (Color3): Color of the slider track.
*   `FillColor` (Color3): Color of the filled portion of the slider.
*   `HandleColor` (Color3): Color of the slider handle.
*   `BorderColor` (Color3): Border color.
*   `OnChanged` (function): Callback function triggered when the slider value changes. Receives the new numerical value.

### `InputSlider`

A combination of an input field and a slider for precise numerical input.

**Props:**

*   `Min` (number): Minimum value.
*   `Max` (number): Maximum value.
*   `Step` (number): Increment/decrement step for the slider and input.
*   `DefaultValue` (number): Initial value.
*   `Width` (number): Width of the component.
*   `Height` (number): Height of the component.
*   `TrackColor` (Color3): Slider track color.
*   `FillColor` (Color3): Slider fill color.
*   `HandleColor` (Color3): Slider handle color.
*   `BorderColor` (Color3): Border color.
*   `InputBackgroundColor` (Color3): Background color of the input field.
*   `InputTextColor` (Color3): Text color of the input field.
*   `OnChanged` (function): Callback function triggered when the value changes. Receives the new numerical value.

### `ColorPicker`

A component for selecting colors.

**Props:**

*   `DefaultValue` (Color3): Initial color.
*   `Width` (number): Width of the color picker area.
*   `Height` (number): Height of the color picker area.
*   `PreviewSize` (number): Size of the color preview square.
*   `BorderColor` (Color3): Border color.
*   `OnChanged` (function): Callback function triggered when the color changes. Receives the new Color3 value.

### `Paragraph`

Displays multi-line text.

**Props:**

*   `Text` (string): The text content.
*   `TextColor` (Color3): Color of the text.
*   `TextSize` (number): Font size of the text.
*   `Font` (Enum.Font): Font of the text.
*   `Size` (UDim2): Size of the paragraph frame.
*   `TextXAlignment` (Enum.TextXAlignment): Horizontal text alignment.
*   `TextYAlignment` (Enum.TextYAlignment): Vertical text alignment.

### `ImageParagraph`

Displays an image alongside text.

**Props:**

*   `ImageUrl` (string): `rbxassetid://` URL of the image.
*   `Text` (string): The text content.
*   `TextColor` (Color3): Color of the text.
*   `TextSize` (number): Font size of the text.
*   `Font` (Enum.Font): Font of the text.
*   `ImageSize` (UDim2): Size of the image.
*   `LayoutDirection` (string): "Horizontal" or "Vertical" layout for image and text.
*   `Size` (UDim2): Size of the overall component frame.

### `Tabs`

Organizes content into tabbed sections.

**Props:**

*   `Tabs` (table): A table of tab definitions. Each tab is a table with `Name` (string) and `Content` (Roact element).
*   `DefaultTab` (string): The name of the tab to be active initially.
*   `TabButtonHeight` (number): Height of each tab button.
*   `TabButtonColor` (Color3): Background color of inactive tab buttons.
*   `ActiveTabButtonColor` (Color3): Background color of the active tab button.
*   `TextColor` (Color3): Text color of tab buttons.
*   `ContentBackgroundColor` (Color3): Background color of the tab content area.

## Styling & Theming:

The `StyleManager` module provides a centralized way to manage UI colors and themes. You can set the active theme using `AXS.StyleManager:SetTheme("ThemeName")`.

**Available Themes:**

*   `Default` (Dark theme)
*   `Light` (Light theme)

## Contributing:

Feel free to contribute to the AXS UI Library by submitting pull requests or opening issues on the GitHub repository.


