--!strict

local Roact = require(script.Parent.Parent.init).Roact
local BaseComponent = require(script.Parent.BaseComponent)

local Button = Roact.Component:extend("Button")

function Button:init()
    BaseComponent.init(self)
    self:setState({
        isHovered = false,
        isPressed = false,
    })
end

function Button:render()
    local props = self.props
    local state = self.state

    local backgroundColor = props.BackgroundColor or Color3.new(0.2, 0.4, 0.8) -- Default blue
    local textColor = props.TextColor or Color3.new(1, 1, 1) -- Default white
    local text = props.Text or "Button"
    local size = props.Size or UDim2.new(0, 100, 0, 40)
    local position = props.Position or UDim2.new(0.5, 0, 0.5, 0)
    local anchorPoint = props.AnchorPoint or Vector2.new(0.5, 0.5)

    if state.isHovered then
        backgroundColor = backgroundColor:Lerp(Color3.new(0.3, 0.5, 0.9), 0.5) -- Lighter on hover
    end

    if state.isPressed then
        backgroundColor = backgroundColor:Lerp(Color3.new(0.1, 0.3, 0.7), 0.5) -- Darker on press
    end

    return Roact.createElement("TextButton", {
        Size = size,
        Position = position,
        AnchorPoint = anchorPoint,
        BackgroundColor3 = backgroundColor,
        Text = text,
        TextColor3 = textColor,
        TextScaled = true,
        Font = Enum.Font.SourceSans,
        [Roact.Event.MouseEnter] = function()
            self:setState({ isHovered = true })
        end,
        [Roact.Event.MouseLeave] = function()
            self:setState({ isHovered = false })
        end,
        [Roact.Event.MouseButton1Down] = function()
            self:setState({ isPressed = true })
        end,
        [Roact.Event.MouseButton1Up] = function()
            self:setState({ isPressed = false })
        end,
        [Roact.Event.Activated] = props.OnActivated, -- Pass through Activated event
    })
end

return Button


