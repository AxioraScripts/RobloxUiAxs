--!strict

local StyleManager = {}

StyleManager.Themes = {
    Default = {
        Primary = Color3.new(0.2, 0.6, 0.8), -- Blue
        Secondary = Color3.new(0.15, 0.15, 0.15), -- Dark Grey
        Accent = Color3.new(0.8, 0.4, 0.2), -- Orange
        Text = Color3.new(1, 1, 1), -- White
        Border = Color3.new(0.1, 0.1, 0.1), -- Very Dark Grey
        Background = Color3.new(0.1, 0.1, 0.1), -- Black
        InputBackground = Color3.new(0.2, 0.2, 0.2), -- Slightly lighter dark grey
        ToggleOff = Color3.new(0.3, 0.3, 0.3), -- Grey
        ToggleOn = Color3.new(0.2, 0.6, 0.8), -- Blue
        Handle = Color3.new(1, 1, 1), -- White
        OptionBackground = Color3.new(0.25, 0.25, 0.25), -- Medium dark grey
        OptionHover = Color3.new(0.3, 0.3, 0.3), -- Lighter medium dark grey
        SelectedOption = Color3.new(0.2, 0.6, 0.8), -- Blue
    },
    -- Add more themes here (e.g., Light, Green, etc.)
    Light = {
        Primary = Color3.new(0.2, 0.4, 0.8),
        Secondary = Color3.new(0.9, 0.9, 0.9),
        Accent = Color3.new(0.8, 0.2, 0.4),
        Text = Color3.new(0, 0, 0),
        Border = Color3.new(0.7, 0.7, 0.7),
        Background = Color3.new(1, 1, 1),
        InputBackground = Color3.new(0.95, 0.95, 0.95),
        ToggleOff = Color3.new(0.7, 0.7, 0.7),
        ToggleOn = Color3.new(0.2, 0.4, 0.8),
        Handle = Color3.new(0, 0, 0),
        OptionBackground = Color3.new(0.85, 0.85, 0.85),
        OptionHover = Color3.new(0.8, 0.8, 0.8),
        SelectedOption = Color3.new(0.2, 0.4, 0.8),
    },
}

StyleManager.CurrentTheme = StyleManager.Themes.Default

function StyleManager:SetTheme(themeName: string)
    local theme = self.Themes[themeName]
    if theme then
        self.CurrentTheme = theme
    else
        warn("Theme '" .. themeName .. "' not found. Using current theme.")
    end
end

function StyleManager:GetColor(colorName: string): Color3
    local color = self.CurrentTheme[colorName]
    if color then
        return color
    else
        warn("Color '" .. colorName .. "' not found in current theme. Returning black.")
        return Color3.new(0, 0, 0)
    end
end

return StyleManager


