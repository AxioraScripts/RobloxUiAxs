--!strict

local Roact = require(script.Parent.Parent.init).Roact
local BaseComponent = require(script.Parent.BaseComponent)

local MultiDropdown = Roact.Component:extend("MultiDropdown")

function MultiDropdown:init()
    BaseComponent.init(self)
    self:setState({
        IsOpen = false,
        SelectedOptions = self.props.DefaultValue or {},
    })
end

function MultiDropdown:render()
    local props = self.props
    local state = self.state

    local options = props.Options or {}
    local width = props.Width or 200
    local height = props.Height or 30
    local backgroundColor = props.BackgroundColor or Color3.new(0.2, 0.2, 0.2)
    local textColor = props.TextColor or Color3.new(1, 1, 1)
    local borderColor = props.BorderColor or Color3.new(0.1, 0.1, 0.1)
    local optionBackgroundColor = props.OptionBackgroundColor or Color3.new(0.25, 0.25, 0.25)
    local optionHoverColor = props.OptionHoverColor or Color3.new(0.3, 0.3, 0.3)
    local selectedOptionColor = props.SelectedOptionColor or Color3.new(0.2, 0.6, 0.8)

    local dropdownElements = {}

    local displayText = "Select Options..."
    if #state.SelectedOptions > 0 then
        displayText = table.concat(state.SelectedOptions, ", ")
    end

    -- Selected options display
    table.insert(dropdownElements, Roact.createElement("TextButton", {
        Size = UDim2.new(1, 0, 0, height),
        BackgroundColor3 = backgroundColor,
        TextColor3 = textColor,
        Text = displayText,
        Font = Enum.Font.SourceSans,
        TextScaled = true,
        TextXAlignment = Enum.TextXAlignment.Left,
        TextPadding = UDim2.new(0, 10, 0, 0),
        BorderSizePixel = 1,
        BorderColor3 = borderColor,
        [Roact.Event.MouseButton1Click] = function()
            self:setState({ IsOpen = not state.IsOpen })
        end,
    }))

    -- Dropdown options list
    if state.IsOpen then
        local yOffset = height
        for i, optionText in ipairs(options) do
            local isSelected = false
            for _, selected in ipairs(state.SelectedOptions) do
                if selected == optionText then
                    isSelected = true
                    break
                end
            end

            local currentOptionBgColor = isSelected and selectedOptionColor or optionBackgroundColor

            table.insert(dropdownElements, Roact.createElement("TextButton", {
                Size = UDim2.new(1, 0, 0, height),
                Position = UDim2.new(0, 0, 0, yOffset),
                BackgroundColor3 = currentOptionBgColor,
                TextColor3 = textColor,
                Text = optionText,
                Font = Enum.Font.SourceSans,
                TextScaled = true,
                TextXAlignment = Enum.TextXAlignment.Left,
                TextPadding = UDim2.new(0, 10, 0, 0),
                BorderSizePixel = 1,
                BorderColor3 = borderColor,
                [Roact.Event.MouseEnter] = function(rbx)
                    if not isSelected then
                        rbx.BackgroundColor3 = optionHoverColor
                    end
                end,
                [Roact.Event.MouseLeave] = function(rbx)
                    rbx.BackgroundColor3 = currentOptionBgColor
                end,
                [Roact.Event.MouseButton1Click] = function()
                    local newSelectedOptions = table.clone(state.SelectedOptions)
                    if isSelected then
                        -- Remove option
                        for idx, selected in ipairs(newSelectedOptions) do
                            if selected == optionText then
                                table.remove(newSelectedOptions, idx)
                                break
                            end
                        end
                    else
                        -- Add option
                        table.insert(newSelectedOptions, optionText)
                    end
                    self:setState({ SelectedOptions = newSelectedOptions })
                    if props.OnChanged then
                        props.OnChanged(newSelectedOptions)
                    end
                end,
            }))
            yOffset = yOffset + height
        end
    end

    return Roact.createElement("Frame", {
        Size = UDim2.new(0, width, 0, state.IsOpen and (height * (#options + 1)) or height), -- Adjust height based on open state
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
    }, dropdownElements)
end

return MultiDropdown


