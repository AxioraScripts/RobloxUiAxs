--!strict

local Roact = require(script.Parent.Parent.init).Roact
local BaseComponent = require(script.Parent.BaseComponent)

local Paragraph = Roact.Component:extend("Paragraph")

function Paragraph:render()
    local props = self.props

    local text = props.Text or ""
    local textColor = props.TextColor or Color3.new(1, 1, 1)
    local textSize = props.TextSize or 14
    local font = props.Font or Enum.Font.SourceSans
    local size = props.Size or UDim2.new(1, 0, 0, 50) -- Default size, height will adjust with TextWrapped
    local textXAlignment = props.TextXAlignment or Enum.TextXAlignment.Left
    local textYAlignment = props.TextYAlignment or Enum.TextYAlignment.Top

    return Roact.createElement("TextLabel", {
        Size = size,
        BackgroundTransparency = 1,
        Text = text,
        TextColor3 = textColor,
        TextSize = textSize,
        Font = font,
        TextWrapped = true, -- Important for multi-line text
        TextXAlignment = textXAlignment,
        TextYAlignment = textYAlignment,
    })
end

return Paragraph


