--!strict

local Roact = require(script.Parent.Parent.init).Roact
local BaseComponent = require(script.Parent.BaseComponent)

local InputSlider = Roact.Component:extend("InputSlider")

function InputSlider:init()
    BaseComponent.init(self)
    self:setState({
        Value = self.props.DefaultValue or 0,
        IsDragging = false,
    })
end

function InputSlider:render()
    local props = self.props
    local state = self.state

    local width = props.Width or 250
    local height = props.Height or 40
    local min = props.Min or 0
    local max = props.Max or 100
    local step = props.Step or 1
    local trackColor = props.TrackColor or Color3.new(0.3, 0.3, 0.3)
    local fillColor = props.FillColor or Color3.new(0.2, 0.6, 0.8)
    local handleColor = props.HandleColor or Color3.new(1, 1, 1)
    local borderColor = props.BorderColor or Color3.new(0.1, 0.1, 0.1)
    local inputBackgroundColor = props.InputBackgroundColor or Color3.new(0.2, 0.2, 0.2)
    local inputTextColor = props.InputTextColor or Color3.new(1, 1, 1)

    local normalizedValue = (state.Value - min) / (max - min)
    local fillWidth = normalizedValue * (width - 50) -- Adjust for input field width
    local handlePositionX = normalizedValue * (width - 50) - (height / 2) -- Center handle

    return Roact.createElement("Frame", {
        Size = UDim2.new(0, width, 0, height),
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
    }, {
        -- Input field
        InputField = Roact.createElement("TextBox", {
            Size = UDim2.new(0, 50, 1, 0),
            Position = UDim2.new(1, -50, 0, 0),
            BackgroundColor3 = inputBackgroundColor,
            TextColor3 = inputTextColor,
            Text = tostring(math.floor(state.Value / step) * step), -- Display stepped value
            Font = Enum.Font.SourceSans,
            TextScaled = false,
            TextSize = 14,
            ClearTextOnFocus = false,
            BorderSizePixel = 1,
            BorderColor3 = borderColor,
            [Roact.Event.FocusLost] = function(rbx, enterPressed)
                local newValue = tonumber(rbx.Text)
                if newValue then
                    newValue = math.clamp(math.floor(newValue / step) * step, min, max)
                    self:setState({ Value = newValue })
                    if props.OnChanged then
                        props.OnChanged(newValue)
                    end
                else
                    rbx.Text = tostring(math.floor(state.Value / step) * step) -- Revert if invalid input
                end
            end,
            [Roact.Event.Changed] = function(rbx)
                -- Allow temporary invalid input for typing, actual update on FocusLost
            end,
        }),

        -- Slider track
        SliderTrack = Roact.createElement("Frame", {
            Size = UDim2.new(1, -60, 0, height / 2), -- Adjust for input field and center vertically
            Position = UDim2.new(0, 0, 0.5, -height / 4),
            BackgroundColor3 = trackColor,
            BorderSizePixel = 1,
            BorderColor3 = borderColor,
            CornerRadius = UDim.new(0.5, 0),
            [Roact.Event.InputBegan] = function(rbx, input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 then
                    self:setState({ IsDragging = true })
                    local newX = input.Position.X - rbx.AbsolutePosition.X
                    local newValue = math.clamp(min + (newX / (width - 60)) * (max - min), min, max)
                    newValue = math.floor(newValue / step) * step -- Apply step
                    self:setState({ Value = newValue })
                    if props.OnChanged then
                        props.OnChanged(newValue)
                    end
                end
            end,
            [Roact.Event.InputEnded] = function(rbx, input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 then
                    self:setState({ IsDragging = false })
                end
            end,
            [Roact.Event.InputChanged] = function(rbx, input)
                if input.UserInputType == Enum.UserInputType.MouseMovement and state.IsDragging then
                    local newX = input.Position.X - rbx.AbsolutePosition.X
                    local newValue = math.clamp(min + (newX / (width - 60)) * (max - min), min, max)
                    newValue = math.floor(newValue / step) * step -- Apply step
                    self:setState({ Value = newValue })
                    if props.OnChanged then
                        props.OnChanged(newValue)
                    end
                end
            end,
        }, {
            Fill = Roact.createElement("Frame", {
                Size = UDim2.new(0, fillWidth, 1, 0),
                BackgroundColor3 = fillColor,
                BorderSizePixel = 0,
                CornerRadius = UDim.new(0.5, 0),
            }),
            Handle = Roact.createElement("Frame", {
                Size = UDim2.new(0, height / 2, 0, height / 2), -- Handle is square, half height of component
                Position = UDim2.new(0, handlePositionX, 0.5, 0),
                AnchorPoint = Vector2.new(0.5, 0.5),
                BackgroundColor3 = handleColor,
                BorderSizePixel = 1,
                BorderColor3 = borderColor,
                CornerRadius = UDim.new(0.5, 0),
            }),
        }),
    })
end

return InputSlider


