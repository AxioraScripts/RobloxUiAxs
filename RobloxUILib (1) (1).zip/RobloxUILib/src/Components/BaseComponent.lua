--!strict

local Roact = require(script.Parent.Parent.init).Roact

local BaseComponent = Roact.Component:extend("BaseComponent")

function BaseComponent:init()
    -- Initialize state or perform setup common to all components
    self.state = self.state or {}
end

function BaseComponent:render()
    -- This method should be overridden by child components
    error("BaseComponent:render() must be implemented by child classes")
end

return BaseComponent


