--!strict

local Roact = require(script.Parent.Parent.init).Roact
local BaseComponent = require(script.Parent.BaseComponent)

local Tabs = Roact.Component:extend("Tabs")

function Tabs:init()
    BaseComponent.init(self)
    self:setState({
        ActiveTab = self.props.DefaultTab or (self.props.Tabs and self.props.Tabs[1].Name) or "",
    })
end

function Tabs:render()
    local props = self.props
    local state = self.state

    local tabs = props.Tabs or {} -- Expected format: {{Name = "Tab1", Content = Roact.createElement(...)}, ...}
    local tabButtonHeight = props.TabButtonHeight or 30
    local tabButtonColor = props.TabButtonColor or Color3.new(0.2, 0.2, 0.2)
    local activeTabButtonColor = props.ActiveTabButtonColor or Color3.new(0.3, 0.3, 0.3)
    local textColor = props.TextColor or Color3.new(1, 1, 1)
    local contentBackgroundColor = props.ContentBackgroundColor or Color3.new(0.15, 0.15, 0.15)

    local tabButtons = {}
    local currentContent = nil

    for i, tab in ipairs(tabs) do
        local isSelected = (tab.Name == state.ActiveTab)
        local buttonColor = isSelected and activeTabButtonColor or tabButtonColor

        table.insert(tabButtons, Roact.createElement("TextButton", {
            Size = UDim2.new(1, 0, 0, tabButtonHeight),
            Position = UDim2.new(0, 0, 0, (i - 1) * tabButtonHeight),
            BackgroundColor3 = buttonColor,
            TextColor3 = textColor,
            Text = tab.Name,
            Font = Enum.Font.SourceSansBold,
            TextScaled = true,
            BorderSizePixel = 0,
            [Roact.Event.MouseButton1Click] = function()
                self:setState({ ActiveTab = tab.Name })
            end,
        }))

        if isSelected then
            currentContent = tab.Content
        end
    end

    return Roact.createElement("Frame", {
        Size = props.Size or UDim2.new(1, 0, 1, 0),
        BackgroundTransparency = 1,
        BorderSizePixel = 0,
    }, {
        TabButtonsFrame = Roact.createElement("Frame", {
            Size = UDim2.new(0.2, 0, 1, 0), -- 20% width for tab buttons
            BackgroundColor3 = tabButtonColor,
            BorderSizePixel = 0,
        }, tabButtons),

        TabContentFrame = Roact.createElement("Frame", {
            Size = UDim2.new(0.8, 0, 1, 0), -- 80% width for content
            Position = UDim2.new(0.2, 0, 0, 0),
            BackgroundColor3 = contentBackgroundColor,
            BorderSizePixel = 0,
        }, {
            Content = currentContent,
        }),
    })
end

return Tabs


